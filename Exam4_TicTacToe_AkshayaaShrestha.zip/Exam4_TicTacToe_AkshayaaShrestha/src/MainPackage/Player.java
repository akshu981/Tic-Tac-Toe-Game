
package MainPackage;


public class Player {
    private String labelText;
    private boolean goesFirst;
    private int Id;
    private String name;
    
    public Player(String labelText, boolean goesFirst, int Id, String name)
    {
        this.labelText= labelText;
        this.goesFirst= goesFirst;
        this.Id= Id;
        this.name=name;
    }
    
    public String getLabelText()
    {
        return labelText;
    }

    public boolean isGoesFirst() {
        return goesFirst;
    }

    public void setGoesFirst(boolean goesFirst) {
        this.goesFirst = goesFirst;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
