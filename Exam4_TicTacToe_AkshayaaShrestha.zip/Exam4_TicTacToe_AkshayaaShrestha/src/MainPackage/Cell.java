
package MainPackage;

import AlgorithmPackage.ICellable;


public class Cell implements ICellable{
    
    private int row;
    private int col;
    private Player owner;
    private int ownerId;

    public Cell(int row, int col, Player owner) {
        this.row = row;
        this.col = col;
        this.owner= owner;
    }
    
    public Cell(int row, int col)
    {
        this.row= row;
        this.col=col;
    }
    
    @Override
    public int getRow() {
        return row;
    }

    @Override
    public int getCol() {
        return col;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

    
    public boolean equals(Object objCell)
    {
        if(objCell==null)
            return false;
        return true;
    }

    @Override
    public void setOwnerId(int ownerID) {
        this.ownerId= ownerID;
    }

    @Override
    public int getOwnerId() {
        return ownerId;
    }

    @Override
    public boolean isEmpty() {
        return owner !=null;
    }

    @Override
    public boolean isTaken() {
        return owner ==null;
    }
    
}
