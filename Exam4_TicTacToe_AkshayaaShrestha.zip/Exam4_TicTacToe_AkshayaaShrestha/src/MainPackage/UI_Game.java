
package MainPackage;

import AlgorithmPackage.Algorithm;
import AlgorithmPackage.AlgorithmBase;
import AlgorithmPackage.ICellable;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class UI_Game extends javax.swing.JFrame {

    private Grid grid;
    private JPanel pnlGrid;
    
    
    private Player playerUser;
    private Player playerAI;
    
    private int winNumber;
    private int gridSize;
    private int difficultyLevel;
    
    private int aiCounter;
    private int userCounter;
    private int drawCounter;
    
    private String userName;
    private boolean userGoesFirst;
    
    
    public UI_Game(int size, String userName, boolean userGoesFirst,int difficultyLevel) {
        setFormUIDefaults();

        initComponents();
        
        setSize(450, 450);
        
        
        this.userName=userName;
        this.userGoesFirst= userGoesFirst;
        
        gridSize=size;
        this.difficultyLevel=difficultyLevel;
        
        
        lblDiffNumber.setText(getDifficultyLevel(difficultyLevel));
        lblWinByNum.setText(getCellsToWin(size));
        
        
        setPlayers(userName, userGoesFirst);
        
        int formWidth=this.getSize().width;
        lblResult.setSize(formWidth,150);

        int panelSize= 250;
        
        pnlGridContainer.setSize(panelSize,panelSize);
        
        pnlGrid= new JPanel();
        pnlGrid.setLayout(new java.awt.GridLayout(size,size));
        
        pnlGrid.setSize(panelSize-10,pnlGridContainer.getHeight()-5);
        pnlGrid.setMaximumSize(new Dimension(panelSize,panelSize));
        pnlGrid.setPreferredSize(new Dimension(panelSize,panelSize));
        
        pnlGridContainer.add(pnlGrid);
        pnlGridContainer.setVisible(true);
        
        populateGrid(size, difficultyLevel);
        
        initFirstMove(size);
        
    }
    
    
    
    private void setPlayers(String userName, boolean userGoesFirst)
    {
        this.userGoesFirst= userGoesFirst;
        String userLabel="";
        String compLabel="";
        int userOwnerId=0;
        int aiOwnerId=0;
        
        if(userGoesFirst)
        {
            userLabel="x";
            compLabel="o";
            userOwnerId=1;
            aiOwnerId=2;
        }
        else
        {
            userLabel="o";
            compLabel="x";
            userOwnerId=2;
            aiOwnerId=1;
        }
        
        playerUser= new Player(userLabel,userGoesFirst,userOwnerId,userName);
        playerAI= new Player(compLabel,!userGoesFirst,aiOwnerId,"AI");
        
        lblUserName.setText(userName+ "("+ userLabel+ ")");
        lblComputer.setText("Computer"+ "("+compLabel+ ")");
        lblTies.setText("Ties");
        lblUserWinCount.setText("0");
        lblTieCount.setText("0");
        lblComputerCount.setText("0");
    }
    
    public void selectCellForAI(Cell cell)
    {
        for(Component cellComponent: pnlGrid.getComponents())
            if(cellComponent instanceof CellIcon)
            {
                CellIcon icon= (CellIcon)cellComponent;
                if(icon.equals(cell))
                {
                    grid.setCellOwner(cell, playerAI);
                    icon.set(playerAI.getLabelText());
                    icon.setForeground(new java.awt.Color(173,5,120));
                    this.repaint();
                    this.revalidate();
                    break;
                }
            }
    }
        
    public void showDraw()
    {
        for(Component cellComponent: pnlGrid.getComponents())
        {
            ((CellIcon)cellComponent).setEnabled(false);
        }
        
        drawCounter++;
        lblResult.setText("Tie");
        lblTieCount.setText(String.valueOf(drawCounter));
        
        this.repaint();
        this.revalidate();
            
    }
    
    private void initFirstMove(int size)
    {
        populateGrid(size, difficultyLevel);
        
        //make move for AI if needed
        if(!userGoesFirst)
        {
            Cell aiCell= grid.nextMove(playerAI);
            selectCellForAI(aiCell);
        }
    }
    
    private void setFormUIDefaults()
    {
        setResizable(false);
        setPosition();
        setAlwaysOnTop(true);
        setBG("/images/WesleaynBG.jpg");
    }
    
    private void setPosition()
    {
        Dimension dimension= Toolkit.getDefaultToolkit().getScreenSize();
        int x= (int)((dimension.getWidth()-getWidth())/2);
        int y= (int)((dimension.getHeight()-getHeight())/2);
        setLocation(x,y);
        
    }
    
    private void setBG(String sImageName)
    {
        setContentPane(new JLabel(new ImageIcon(getClass().getResource(sImageName))));
    }
    
    
    
    private boolean isGameOver()
    {
        boolean isOver=false;
        boolean aiWon=false;
        boolean userWon= grid.checkWinner(playerUser.getId());
        if(userWon)
        {
            this.userCounter++;
            lblUserWinCount.setText(userCounter+ "");
            lblResult.setText(playerUser.getName()+ " is Winner!");
            highlightWinner(grid.getWinningCells(),true);
            isOver=true;
            
        }
        else
        {
           aiWon= grid.checkWinner(playerAI.getId());
           if(aiWon)
           {
               aiCounter++;
               highlightWinner(grid.getWinningCells(),false);
               lblResult.setText("Computer won!");
               lblComputerCount.setText(aiCounter+ "");
               isOver=true;
           }
           
        }
        
        if(!aiWon && !userWon)
        {
            if(grid.isGameOver())
            {
                showDraw();
                isOver= true;
            }
        }
        return isOver;
    }
    
    public void highlightWinner(ArrayList<ICellable> arWinCells, boolean needUser)
    {
        for(Component cellComponent: pnlGrid.getComponents())
            ((CellIcon)cellComponent).setEnabled(false);
        
        for(ICellable cell: arWinCells)
        {
            for(Component cellComponent: pnlGrid.getComponents())
            {
                CellIcon icon= (CellIcon)cellComponent;
                if(icon.equals(cell))
                {
                    if(needUser)
                    {
                        icon.setForeground(new java.awt.Color(85,162,85));
                        icon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(85,162,85)));
                        
                    }
                    else
                    {
                        icon.setForeground(new java.awt.Color(240,30,30));
                        icon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(240,30,30)));
                    }
                    this.repaint();
                    this.revalidate();
                    break;
                }
            }
        }
        
    }
            
            
    private String getDifficultyLevel(int diffLevel)
    {
        if(diffLevel==1)
            return "Easy";
        if(diffLevel==2)
            return "Medium";
        if(diffLevel==3)
            return "Hard";
        
        return "";
    }
    
    private String getCellsToWin(int size)
    {
        if(size==3)
            return "3";
        if(size==4)
            return "4";
        if(size==5)
            return "4";
        
        return "";
    }

    public void populateGrid(int size, int difficultyLevel)
    {
      pnlGrid.removeAll();
      
      grid= new Grid(size, difficultyLevel);
      
      for(int i=0; i< size; i++)
      {
          for(int n=0; n<size; n++)
          {
              Cell cell= new Cell(i,n);
              grid.addCell(cell);
              
              CellIcon cellIcon= new CellIcon(cell);
              
              cellIcon.addMouseListener(new java.awt.event.MouseAdapter()
              {
                  public void mouseEntered(java.awt.event.MouseEvent evt)
                  {
                      if(!cellIcon.isEnabled())
                          return;
                      cellIcon.setHoverStyle(playerUser.getLabelText());
                      
                  }
                  
                  public void mouseExited(java.awt.event.MouseEvent evt)
                  {
                      if(!cellIcon.isEnabled())
                          return;
                      //cellIcon.setNormalStyle();
                      
                  }
                  
                  public void mouseClicked(java.awt.event.MouseEvent evt)
                  {
                      if(!cellIcon.isEnabled())
                          return;
                      
                      cellIcon.set(playerUser.getLabelText());
                      cellIcon.setOwner(playerUser);
                      grid.setCellOwner(cellIcon.getCell(),playerUser);
                      
                      
                      if(!isGameOver())
                      {
                          Cell aiCell= grid.nextMove(playerAI);
                          selectCellForAI(aiCell);
                          isGameOver();
                      }

                  }
                  
                  
              });
              pnlGrid.add(cellIcon);
          }
      }
      
    }
    

        /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblResult = new javax.swing.JLabel();
        btnReplay = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        pnlRight = new javax.swing.JPanel();
        lblLevel = new javax.swing.JLabel();
        lblDiffNumber = new javax.swing.JLabel();
        pnlCount = new javax.swing.JPanel();
        lblUserName = new javax.swing.JLabel();
        lblTies = new javax.swing.JLabel();
        lblComputer = new javax.swing.JLabel();
        lblUserWinCount = new javax.swing.JLabel();
        lblTieCount = new javax.swing.JLabel();
        lblComputerCount = new javax.swing.JLabel();
        pnlLeft = new javax.swing.JPanel();
        lblWinBy = new javax.swing.JLabel();
        lblWinByNum = new javax.swing.JLabel();
        pnlGridContainer = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(450, 450));
        getContentPane().setLayout(null);

        pnlHeader.setOpaque(false);

        lblResult.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblResult.setForeground(new java.awt.Color(102, 0, 102));
        lblResult.setText("           Tic Tac Toe");

        btnReplay.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnReplay.setForeground(new java.awt.Color(102, 0, 102));
        btnReplay.setText("REPLAY");
        btnReplay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnReplayMouseClicked(evt);
            }
        });
        btnReplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReplayActionPerformed(evt);
            }
        });

        btnReset.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnReset.setForeground(new java.awt.Color(102, 0, 102));
        btnReset.setText("RESET");
        btnReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnResetMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnReset)
                .addGap(71, 71, 71)
                .addComponent(lblResult, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(btnReplay)
                .addContainerGap(133, Short.MAX_VALUE))
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnReset)
                    .addComponent(lblResult)
                    .addComponent(btnReplay))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        getContentPane().add(pnlHeader);
        pnlHeader.setBounds(0, 0, 540, 60);

        pnlRight.setOpaque(false);

        lblLevel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblLevel.setForeground(new java.awt.Color(102, 0, 102));
        lblLevel.setText("Difficulty");

        lblDiffNumber.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblDiffNumber.setText("Easy");

        javax.swing.GroupLayout pnlRightLayout = new javax.swing.GroupLayout(pnlRight);
        pnlRight.setLayout(pnlRightLayout);
        pnlRightLayout.setHorizontalGroup(
            pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblLevel, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
            .addGroup(pnlRightLayout.createSequentialGroup()
                .addComponent(lblDiffNumber, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlRightLayout.setVerticalGroup(
            pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRightLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLevel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDiffNumber)
                .addContainerGap(380, Short.MAX_VALUE))
        );

        getContentPane().add(pnlRight);
        pnlRight.setBounds(340, 60, 66, 435);

        pnlCount.setOpaque(false);

        lblUserName.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblUserName.setForeground(new java.awt.Color(102, 0, 102));
        lblUserName.setText("User");

        lblTies.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblTies.setForeground(new java.awt.Color(102, 0, 102));
        lblTies.setText("Ties");

        lblComputer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblComputer.setText("Computer");

        lblUserWinCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblUserWinCount.setText("User win Count");

        lblTieCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblTieCount.setText("Tie Count");

        lblComputerCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblComputerCount.setText("Computer win count");

        javax.swing.GroupLayout pnlCountLayout = new javax.swing.GroupLayout(pnlCount);
        pnlCount.setLayout(pnlCountLayout);
        pnlCountLayout.setHorizontalGroup(
            pnlCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCountLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCountLayout.createSequentialGroup()
                        .addComponent(lblUserName, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblTies))
                    .addGroup(pnlCountLayout.createSequentialGroup()
                        .addComponent(lblUserWinCount, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(lblTieCount)))
                .addGap(45, 45, 45)
                .addGroup(pnlCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblComputer, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblComputerCount, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        pnlCountLayout.setVerticalGroup(
            pnlCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCountLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUserName)
                    .addComponent(lblTies)
                    .addComponent(lblComputer))
                .addGap(4, 4, 4)
                .addGroup(pnlCountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUserWinCount)
                    .addComponent(lblTieCount)
                    .addComponent(lblComputerCount))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        getContentPane().add(pnlCount);
        pnlCount.setBounds(0, 330, 360, 91);

        pnlLeft.setOpaque(false);

        lblWinBy.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblWinBy.setForeground(new java.awt.Color(102, 0, 102));
        lblWinBy.setText("Win by");

        lblWinByNum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblWinByNum.setText("3");

        javax.swing.GroupLayout pnlLeftLayout = new javax.swing.GroupLayout(pnlLeft);
        pnlLeft.setLayout(pnlLeftLayout);
        pnlLeftLayout.setHorizontalGroup(
            pnlLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblWinBy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pnlLeftLayout.createSequentialGroup()
                .addComponent(lblWinByNum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlLeftLayout.setVerticalGroup(
            pnlLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblWinBy)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblWinByNum)
                .addContainerGap(225, Short.MAX_VALUE))
        );

        getContentPane().add(pnlLeft);
        pnlLeft.setBounds(0, 60, 38, 280);

        javax.swing.GroupLayout pnlGridContainerLayout = new javax.swing.GroupLayout(pnlGridContainer);
        pnlGridContainer.setLayout(pnlGridContainerLayout);
        pnlGridContainerLayout.setHorizontalGroup(
            pnlGridContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        pnlGridContainerLayout.setVerticalGroup(
            pnlGridContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );

        getContentPane().add(pnlGridContainer);
        pnlGridContainer.setBounds(80, 70, 250, 230);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnReplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReplayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnReplayActionPerformed

    private void btnReplayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReplayMouseClicked
        lblResult.setText("");
        populateGrid(this.gridSize, difficultyLevel);
        initFirstMove(this.gridSize);
        
    }//GEN-LAST:event_btnReplayMouseClicked

    private void btnResetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnResetMouseClicked
        (new UI_Enter()).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnResetMouseClicked

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnReplay;
    private javax.swing.JButton btnReset;
    private javax.swing.JLabel lblComputer;
    private javax.swing.JLabel lblComputerCount;
    private javax.swing.JLabel lblDiffNumber;
    private javax.swing.JLabel lblLevel;
    private javax.swing.JLabel lblResult;
    private javax.swing.JLabel lblTieCount;
    private javax.swing.JLabel lblTies;
    private javax.swing.JLabel lblUserName;
    private javax.swing.JLabel lblUserWinCount;
    private javax.swing.JLabel lblWinBy;
    private javax.swing.JLabel lblWinByNum;
    private javax.swing.JPanel pnlCount;
    private javax.swing.JPanel pnlGridContainer;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlLeft;
    private javax.swing.JPanel pnlRight;
    // End of variables declaration//GEN-END:variables
}
