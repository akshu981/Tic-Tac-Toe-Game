
package MainPackage;

import AlgorithmPackage.Algorithm;
import AlgorithmPackage.AlgorithmBase;
import AlgorithmPackage.ICellable;
import java.util.ArrayList;


public class Grid {
   ICellable[][] grid;
   AlgorithmPackage.Algorithm algo;
   
   public Grid(int size, int difficultyLevel)
   {
       grid= new Cell[size][size];
       Algorithm.DIFFICULTY level= Algorithm.DIFFICULTY.EASY;
       
       if(difficultyLevel==2)
           level=Algorithm.DIFFICULTY.MEDIUM;
       if(difficultyLevel==3)
           level= Algorithm.DIFFICULTY.HARD;
       
       algo= new Algorithm(grid, level);
   }
   
   public int getWinNumber()
   {
       return algo.getNumberToWin();
   }
   
    public void addCell(Cell cell)
   {
       grid[cell.getRow()][cell.getCol()]=cell;
   }
    
     public Cell nextMove(Player player)
   {
       String sErr="";
       ICellable nextCell= algo.MakeMove(player.getId());
       if(nextCell==null)
       {
           sErr="";
       }
       
       Cell cell=getCellFromCellable(nextCell, player);
       
       return cell;
   }
     
      private Cell getCellFromCellable(ICellable cell, Player player)
   {
       int lastIndex=grid[0].length;
       int iRow=cell.getRow();
       int iCol=cell.getCol();
       Cell c=(Cell)grid[iRow][iCol];
       c.setOwner(player);
       
       return c;
   }
    
   public void setCellOwner(Cell cell, Player player)
   {
       Cell c= getCellFromCellable(cell, player);
       algo.RegisterMove(cell, player.getId());
   }
   
   public ArrayList<ICellable> getWinningCells()
   {
       return algo.getWinningCells();
   }
   
   public boolean isGameOver()
   {
       return algo.isGameOver();
   }
   
  
   
   public boolean checkWinner(int ownerID)
   {
       return algo.checkWinner(ownerID);
   }
   
  
   
   
   
   
   
   
   
   
}
