
package MainPackage;

import AlgorithmPackage.ICellable;


public class CellIcon extends javax.swing.JLabel {
    private Cell cell;
    public static final int BASE_SIZE=60;
    
    
    
    
    public CellIcon(Cell cell)
    {
        this.cell= cell;
        
        this.setBackground(new java.awt.Color(255,255,255));
        this.setForeground(new java.awt.Color(112,71,140));
        this.setSize(BASE_SIZE, BASE_SIZE);
        
        this.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(112,71,140),3));
        this.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        this.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        this.setFont(new java.awt.Font("Cambria",1,30));
    }
    
    public void setHoverStyle(String sText)
    {
        if(this.getText()==null || this.getText().equalsIgnoreCase(""))
        {
            this.setBackground(new java.awt.Color(112,71,140));
            this.setForeground(new java.awt.Color(255,255,255));
            this.setText(sText);
            this.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        }
        else
        {
           this.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            
        }
    }
    
    public void setNormalStyle()
    {
        if(cell.isEmpty())
        {
            this.setBackground(new java.awt.Color(240,240,240));
            this.setForeground(new java.awt.Color(112,71,140));
            this.setText(null);
        }
    }
    
    public void set(String sText)
    {
        this.setText(sText);
        this.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        this.setBackground(new java.awt.Color(240,240,240));
        this.setForeground(new java.awt.Color(112,71,140));
        
    }
    
    public Cell getCell()
    {
        return cell;
    }

    public void setOwner(Player owner) {
        cell.setOwner(owner);
    }
    

    public int getRow() {
        return cell.getRow();
    }
    
    public int getCol() {
        return cell.getCol();
    }

    
    
    public boolean equals(ICellable otherCell)
    {
        if(otherCell==null)
            return false;
        
        return (this.getRow()==otherCell.getRow() && this.getCol()==otherCell.getCol());
    }
    
    
}
