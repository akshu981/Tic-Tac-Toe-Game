
package MainPackage;


public class Program {

    
    public static void main(String[] args) {
        
        UI_Enter form= new UI_Enter();
        form.setVisible(true);
        //(new UI_Game(3,"Akshayaa",true,3)).setVisible(true);
    }
    
}
